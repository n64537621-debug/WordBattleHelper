package com.example.wordbattlehelper

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "capture_data"
        private const val CHANNEL = "word_battle_capture"
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private val busy = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private lateinit var dictionary: List<String>
    private var lastPrefix = ""
    private var lastProcessAt = 0L

    override fun onCreate() {
        super.onCreate()
        dictionary = assets.open("words.txt").bufferedReader().useLines { lines ->
            lines.map { it.trim().lowercase(Locale.ROOT) }
                .filter { it.matches(Regex("[a-z]{2,20}")) }.distinct().toList()
        }
        createNotificationChannel()
        showOverlay("Word Battle Helper\\nОжидание букв…")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, Notification.Builder(this, CHANNEL)
            .setContentTitle("Word Battle Helper")
            .setContentText("Распознавание экрана включено")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (resultCode == Activity.RESULT_OK && data != null) startCapture(resultCode, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        thread = HandlerThread("screen-ocr").also { it.start() }
        worker = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastProcessAt < 450 || !busy.compareAndSet(false, true)) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastProcessAt = now
            val image = source.acquireLatestImage()
            if (image == null) { busy.set(false); return@setOnImageAvailableListener }
            val bitmap = imageToBitmap(image)
            image.close()
            if (bitmap == null) { busy.set(false); return@setOnImageAvailableListener }
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    val prefix = extractPrefix(result, width, height)
                    if (prefix.isNotBlank() && prefix != lastPrefix) {
                        lastPrefix = prefix
                        val matches = dictionary.asSequence().filter { it.startsWith(prefix.lowercase()) }
                            .take(80).toList()
                        showOverlay("Префикс: $prefix\\nНайдено: ${matches.size}+\\n" +
                            matches.take(24).joinToString("   "))
                    }
                }
                .addOnFailureListener { }
                .addOnCompleteListener { bitmap.recycle(); busy.set(false) }
        }, worker)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "WordBattleScreen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            cropped
        } catch (_: Exception) { null }
    }

    private fun extractPrefix(result: Text, screenWidth: Int, screenHeight: Int): String {
        val lines = result.textBlocks.flatMap { it.lines }
        val prompt = lines.firstOrNull {
            it.text.lowercase().contains("starting with")
        } ?: return ""
        val promptBox = prompt.boundingBox ?: return ""
        val candidates = lines.filter { line ->
            val box = line.boundingBox ?: return@filter false
            box.top >= promptBox.bottom - 4 &&
            box.top < promptBox.bottom + (screenHeight * 0.16f).toInt() &&
            box.centerX() > screenWidth * 0.25f &&
            box.centerX() < screenWidth * 0.80f
        }.sortedBy { it.boundingBox?.left ?: 0 }

        val chars = candidates.mapNotNull { line ->
            val token = line.text.uppercase(Locale.ROOT).replace(Regex("[^A-Z]"), "")
            if (token.isNotEmpty() && token.length <= 12) token else null
        }.joinToString("")
        return chars.take(12)
    }

    private fun showOverlay(message: String) {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        if (overlay == null) {
            overlay = TextView(this).apply {
                textSize = 13f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xDD20242C.toInt())
                setPadding(18, 14, 18, 14)
            }
            val params = WindowManager.LayoutParams(
                (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 100 }
            try { wm.addView(overlay, params) } catch (_: Exception) { }
        }
        overlay?.text = message
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen recognition", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
